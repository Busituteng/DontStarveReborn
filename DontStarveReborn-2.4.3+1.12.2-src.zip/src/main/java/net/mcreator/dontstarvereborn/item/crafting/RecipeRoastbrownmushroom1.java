
package net.mcreator.dontstarvereborn.item.crafting;

import net.minecraftforge.fml.common.registry.GameRegistry;
import net.minecraftforge.fml.common.event.FMLInitializationEvent;

import net.minecraft.item.ItemStack;
import net.minecraft.init.Blocks;

import net.mcreator.dontstarvereborn.item.ItemRoastbrownmushroom;
import net.mcreator.dontstarvereborn.ElementsDontStarveReborn;

@ElementsDontStarveReborn.ModElement.Tag
public class RecipeRoastbrownmushroom1 extends ElementsDontStarveReborn.ModElement {
	public RecipeRoastbrownmushroom1(ElementsDontStarveReborn instance) {
		super(instance, 83);
	}

	@Override
	public void init(FMLInitializationEvent event) {
		GameRegistry.addSmelting(new ItemStack(Blocks.BROWN_MUSHROOM, (int) (1)), new ItemStack(ItemRoastbrownmushroom.block, (int) (1)), 0F);
	}
}
