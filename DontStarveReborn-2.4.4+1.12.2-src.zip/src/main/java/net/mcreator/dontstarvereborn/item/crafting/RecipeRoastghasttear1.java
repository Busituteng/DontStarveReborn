
package net.mcreator.dontstarvereborn.item.crafting;

import net.minecraftforge.fml.common.registry.GameRegistry;
import net.minecraftforge.fml.common.event.FMLInitializationEvent;

import net.minecraft.item.ItemStack;

import net.mcreator.dontstarvereborn.item.ItemSoakghasttear;
import net.mcreator.dontstarvereborn.item.ItemRoastghasttear;
import net.mcreator.dontstarvereborn.ElementsDontStarveReborn;

@ElementsDontStarveReborn.ModElement.Tag
public class RecipeRoastghasttear1 extends ElementsDontStarveReborn.ModElement {
	public RecipeRoastghasttear1(ElementsDontStarveReborn instance) {
		super(instance, 142);
	}

	@Override
	public void init(FMLInitializationEvent event) {
		GameRegistry.addSmelting(new ItemStack(ItemSoakghasttear.block, (int) (1)), new ItemStack(ItemRoastghasttear.block, (int) (1)), 1F);
	}
}
