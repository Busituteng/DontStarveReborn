
package net.mcreator.dontstarvereborn.item.crafting;

import net.minecraftforge.fml.common.registry.GameRegistry;
import net.minecraftforge.fml.common.event.FMLInitializationEvent;

import net.minecraft.item.ItemStack;

import net.mcreator.dontstarvereborn.item.ItemSoakrottenflesh;
import net.mcreator.dontstarvereborn.item.ItemRoastrottenflesh;
import net.mcreator.dontstarvereborn.ElementsDontStarveReborn;

@ElementsDontStarveReborn.ModElement.Tag
public class RecipeRoastrottenflesh1 extends ElementsDontStarveReborn.ModElement {
	public RecipeRoastrottenflesh1(ElementsDontStarveReborn instance) {
		super(instance, 111);
	}

	@Override
	public void init(FMLInitializationEvent event) {
		GameRegistry.addSmelting(new ItemStack(ItemSoakrottenflesh.block, (int) (1)), new ItemStack(ItemRoastrottenflesh.block, (int) (1)), 0F);
	}
}
