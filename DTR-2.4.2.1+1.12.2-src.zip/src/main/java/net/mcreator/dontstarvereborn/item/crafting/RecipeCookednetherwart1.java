
package net.mcreator.dontstarvereborn.item.crafting;

import net.minecraftforge.fml.common.registry.GameRegistry;
import net.minecraftforge.fml.common.event.FMLInitializationEvent;

import net.minecraft.item.ItemStack;
import net.minecraft.init.Items;

import net.mcreator.dontstarvereborn.item.ItemCookednetherwart;
import net.mcreator.dontstarvereborn.ElementsDontStarveReborn;

@ElementsDontStarveReborn.ModElement.Tag
public class RecipeCookednetherwart1 extends ElementsDontStarveReborn.ModElement {
	public RecipeCookednetherwart1(ElementsDontStarveReborn instance) {
		super(instance, 37);
	}

	@Override
	public void init(FMLInitializationEvent event) {
		GameRegistry.addSmelting(new ItemStack(Items.NETHER_WART, (int) (1)), new ItemStack(ItemCookednetherwart.block, (int) (1)), 0F);
	}
}
