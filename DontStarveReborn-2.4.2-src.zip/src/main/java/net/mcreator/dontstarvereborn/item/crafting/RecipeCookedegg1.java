
package net.mcreator.dontstarvereborn.item.crafting;

import net.minecraftforge.fml.common.registry.GameRegistry;
import net.minecraftforge.fml.common.event.FMLInitializationEvent;

import net.minecraft.item.ItemStack;
import net.minecraft.init.Items;

import net.mcreator.dontstarvereborn.item.ItemCookedegg;
import net.mcreator.dontstarvereborn.ElementsDontStarveReborn;

@ElementsDontStarveReborn.ModElement.Tag
public class RecipeCookedegg1 extends ElementsDontStarveReborn.ModElement {
	public RecipeCookedegg1(ElementsDontStarveReborn instance) {
		super(instance, 29);
	}

	@Override
	public void init(FMLInitializationEvent event) {
		GameRegistry.addSmelting(new ItemStack(Items.EGG, (int) (1)), new ItemStack(ItemCookedegg.block, (int) (1)), 1F);
	}
}
