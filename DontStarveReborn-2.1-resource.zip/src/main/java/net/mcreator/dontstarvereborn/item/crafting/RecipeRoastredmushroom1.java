
package net.mcreator.dontstarvereborn.item.crafting;

import net.minecraftforge.fml.common.registry.GameRegistry;
import net.minecraftforge.fml.common.event.FMLInitializationEvent;

import net.minecraft.item.ItemStack;
import net.minecraft.init.Blocks;

import net.mcreator.dontstarvereborn.item.ItemRoastredmushroom;
import net.mcreator.dontstarvereborn.ElementsDontStarveReborn;

@ElementsDontStarveReborn.ModElement.Tag
public class RecipeRoastredmushroom1 extends ElementsDontStarveReborn.ModElement {
	public RecipeRoastredmushroom1(ElementsDontStarveReborn instance) {
		super(instance, 51);
	}

	@Override
	public void init(FMLInitializationEvent event) {
		GameRegistry.addSmelting(new ItemStack(Blocks.RED_MUSHROOM, (int) (1)), new ItemStack(ItemRoastredmushroom.block, (int) (1)), 0F);
	}
}
