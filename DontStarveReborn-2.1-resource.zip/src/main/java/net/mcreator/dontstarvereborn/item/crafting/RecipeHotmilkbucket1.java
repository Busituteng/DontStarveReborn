
package net.mcreator.dontstarvereborn.item.crafting;

import net.minecraftforge.fml.common.registry.GameRegistry;
import net.minecraftforge.fml.common.event.FMLInitializationEvent;

import net.minecraft.item.ItemStack;
import net.minecraft.init.Items;

import net.mcreator.dontstarvereborn.item.ItemHotmilkbucket;
import net.mcreator.dontstarvereborn.ElementsDontStarveReborn;

@ElementsDontStarveReborn.ModElement.Tag
public class RecipeHotmilkbucket1 extends ElementsDontStarveReborn.ModElement {
	public RecipeHotmilkbucket1(ElementsDontStarveReborn instance) {
		super(instance, 33);
	}

	@Override
	public void init(FMLInitializationEvent event) {
		GameRegistry.addSmelting(new ItemStack(Items.MILK_BUCKET, (int) (1)), new ItemStack(ItemHotmilkbucket.block, (int) (1)), 0F);
	}
}
