
package net.mcreator.dontstarvereborn.item.crafting;

import net.minecraftforge.fml.common.registry.GameRegistry;
import net.minecraftforge.fml.common.event.FMLInitializationEvent;

import net.minecraft.item.ItemStack;

import net.mcreator.dontstarvereborn.item.ItemSoakenderpearl;
import net.mcreator.dontstarvereborn.item.ItemRoastenderpearl;
import net.mcreator.dontstarvereborn.ElementsDontStarveReborn;

@ElementsDontStarveReborn.ModElement.Tag
public class RecipeRoastenderpearl1 extends ElementsDontStarveReborn.ModElement {
	public RecipeRoastenderpearl1(ElementsDontStarveReborn instance) {
		super(instance, 105);
	}

	@Override
	public void init(FMLInitializationEvent event) {
		GameRegistry.addSmelting(new ItemStack(ItemSoakenderpearl.block, (int) (1)), new ItemStack(ItemRoastenderpearl.block, (int) (1)), 0F);
	}
}
