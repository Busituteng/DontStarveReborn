
package net.mcreator.dontstarvereborn.item.crafting;

import net.minecraftforge.fml.common.registry.GameRegistry;
import net.minecraftforge.fml.common.event.FMLInitializationEvent;

import net.minecraft.item.ItemStack;
import net.minecraft.init.Blocks;

import net.mcreator.dontstarvereborn.item.ItemRoastvine;
import net.mcreator.dontstarvereborn.ElementsDontStarveReborn;

@ElementsDontStarveReborn.ModElement.Tag
public class RecipeRoastvine1 extends ElementsDontStarveReborn.ModElement {
	public RecipeRoastvine1(ElementsDontStarveReborn instance) {
		super(instance, 68);
	}

	@Override
	public void init(FMLInitializationEvent event) {
		GameRegistry.addSmelting(new ItemStack(Blocks.VINE, (int) (1)), new ItemStack(ItemRoastvine.block, (int) (1)), 0F);
	}
}
