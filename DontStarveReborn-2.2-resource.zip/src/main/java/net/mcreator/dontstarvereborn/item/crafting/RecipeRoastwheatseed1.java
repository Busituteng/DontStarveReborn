
package net.mcreator.dontstarvereborn.item.crafting;

import net.minecraftforge.fml.common.registry.GameRegistry;
import net.minecraftforge.fml.common.event.FMLInitializationEvent;

import net.minecraft.item.ItemStack;
import net.minecraft.init.Items;

import net.mcreator.dontstarvereborn.item.ItemRoastwheatseed;
import net.mcreator.dontstarvereborn.ElementsDontStarveReborn;

@ElementsDontStarveReborn.ModElement.Tag
public class RecipeRoastwheatseed1 extends ElementsDontStarveReborn.ModElement {
	public RecipeRoastwheatseed1(ElementsDontStarveReborn instance) {
		super(instance, 83);
	}

	@Override
	public void init(FMLInitializationEvent event) {
		GameRegistry.addSmelting(new ItemStack(Items.WHEAT_SEEDS, (int) (1)), new ItemStack(ItemRoastwheatseed.block, (int) (1)), 0F);
	}
}
