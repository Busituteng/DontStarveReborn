
package net.mcreator.dontstarvereborn.item.crafting;

import net.minecraftforge.fml.common.registry.GameRegistry;
import net.minecraftforge.fml.common.event.FMLInitializationEvent;

import net.minecraft.item.ItemStack;
import net.minecraft.init.Items;

import net.mcreator.dontstarvereborn.item.ItemRoastpumpkinseed;
import net.mcreator.dontstarvereborn.ElementsDontStarveReborn;

@ElementsDontStarveReborn.ModElement.Tag
public class RecipeRoastpumpkinseed1 extends ElementsDontStarveReborn.ModElement {
	public RecipeRoastpumpkinseed1(ElementsDontStarveReborn instance) {
		super(instance, 87);
	}

	@Override
	public void init(FMLInitializationEvent event) {
		GameRegistry.addSmelting(new ItemStack(Items.PUMPKIN_SEEDS, (int) (1)), new ItemStack(ItemRoastpumpkinseed.block, (int) (1)), 0F);
	}
}
