
package net.mcreator.dontstarvereborn.util;

import net.minecraftforge.oredict.OreDictionary;
import net.minecraftforge.fml.common.event.FMLInitializationEvent;

import net.minecraft.item.ItemStack;

import net.mcreator.dontstarvereborn.item.ItemIronknife;
import net.mcreator.dontstarvereborn.item.ItemDiamondknife;
import net.mcreator.dontstarvereborn.ElementsDontstarverebornMod;

@ElementsDontstarverebornMod.ModElement.Tag
public class OreDictDsrknife extends ElementsDontstarverebornMod.ModElement {
	public OreDictDsrknife(ElementsDontstarverebornMod instance) {
		super(instance, 54);
	}

	@Override
	public void init(FMLInitializationEvent event) {
		OreDictionary.registerOre("dsr_knife", new ItemStack(ItemDiamondknife.block, (int) (1)));
		OreDictionary.registerOre("dsr_knife", new ItemStack(ItemIronknife.block, (int) (1)));
	}
}
